<h1> Tests </h1>
<link rel="stylesheet" href="style.css">
<?

include "db.php";
$sql = "SELECT * FROM quest";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    echo  $row["jautajums"]. " <br><br> 1.atbilde: " . $row["atbilde1"]." <br> <br> 2.atbilde: " .$row["atbilde2"];
  } 
} else {
  echo "0 results";
}
?>

<html>
        
<style>

body{
        

