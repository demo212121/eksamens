<h1> Jautājuma izveide </h1>

<?php
include "db.php";
if(isset($_POST['save'])){
        $sql = "INSERT INTO quest (jautajums, atbilde1, atbilde2)
        VALUES ('".$_POST["jautajums"]."', '".$_POST["atbilde1"]."', '".$_POST["atbilde2"]."')";
        $results =mysqli_query($conn, $sql);
}

       
?>

     <form method="post">
    <input type="text" placeholder="jautājums"  name="jautajums" required><br><br>
    <input type="text" placeholder="1. atbilde"   name="atbilde1"required><br><br>
    <input type="text"  placeholder="2. atbilde"  name="atbilde2"required><br><br>
  
  <input type="submit" name="save" value="save">
</form>

